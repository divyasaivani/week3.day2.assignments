package week3.day2.assignments;

public interface Software {
	public void softwareResources();
		
	

}
