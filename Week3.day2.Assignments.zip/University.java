package week3.day2.assignments;

public abstract class University {
	public void pg() {
		System.out.println("PG in University");
	}
	public abstract void ug();
	
		
	
		
	

}
