package week3.day2.assignments;

public class Automation extends MultipleLanguage implements Language,TestTool {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public void Selenium() {
		// TODO Auto-generated method stub
	
		
	}

	public void java() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void ruby() {
		// TODO Auto-generated method stub
		
	}

}
