package week3.day2.assignments;

public class College extends University {

	@Override
	public void ug() {
		// TODO Auto-generated method stub
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		College obj = new College();
		obj.pg();
		obj.ug();



}
