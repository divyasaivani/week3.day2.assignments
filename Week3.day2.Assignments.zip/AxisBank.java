package week3.day2.assignments;

public class AxisBank extends BankInfo{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AxisBank obj = new AxisBank();
		obj.deposit();

	}

}
