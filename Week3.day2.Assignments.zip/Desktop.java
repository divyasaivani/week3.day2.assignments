package week3.day2.assignments;

public class Desktop implements Hardware,Software {
	public void desktopModels() {
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public void softwareResources() {
		// TODO Auto-generated method stub
		
	}

	public void hardwareResources() {
		// TODO Auto-generated method stub
		Desktop obj = new Desktop();
		obj.hardwareResources();
		obj.softwareResources();
		obj.desktopModels();
		
	}

}
