package week3.day2.assignments;

public class BankInfo{
public void saving() {
	System.out.println("Savings");
}
public void fixed() {
	System.out.println("Fixed");
	
}
public void deposit() {
	System.out.println("Deposit");
	
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
