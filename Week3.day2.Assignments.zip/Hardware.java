package week3.day2.assignments;

public interface Hardware {
	public void hardwareResources();
	
		
	

}
