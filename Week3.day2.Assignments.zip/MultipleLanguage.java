package week3.day2.assignments;

public abstract class MultipleLanguage {
	public void python() {
		System.out.println("Python Language");
		
	}
 public abstract void ruby();
	
}
