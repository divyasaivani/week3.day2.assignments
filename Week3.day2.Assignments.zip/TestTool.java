package week3.day2.assignments;

public interface TestTool {
	public void Selenium(); 
		
	

}
